
// function submitForm() {
//     const text = document.getElementById('text').value;
//     alert(text);
// }

function submitForm() {
    let loginForm = document.forms.printMessage;
    alert(loginForm.elements.pole_tekstowe.value)
}


